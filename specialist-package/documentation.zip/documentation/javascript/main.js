
$(document).ready(function() {

	$('#nav').onePageNav();
  
});

